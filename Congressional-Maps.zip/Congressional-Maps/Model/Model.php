<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

echo 'This is model';

?>
<!DOCTYPE html>
<html>
    Notes: "The Model represents your data structures. Typically your model 
    classes will contain functions that help you retrieve, insert, and update 
    information in your database."
</html>