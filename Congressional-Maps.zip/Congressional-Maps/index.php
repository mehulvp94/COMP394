<?php
    header("Location: view/main.php");
    exit;
?>
<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <meta charset="UTF-8">

        <title></title>
    </head>
    <body>
    </body>
</html>
